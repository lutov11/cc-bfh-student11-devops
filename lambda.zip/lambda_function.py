import json
import boto3
import os

s3 = boto3.client('s3')
bucket_name = os.environ['RESULT_BUCKET']
def lambda_handler(event, context):
    filename = event.get('filename')
    filetext = event.get('filetext')

    if not filename or not filetext:
        return {
            'statusCode': 400,
            'body': 'Missing filename or filetext'        }

    s3.put_object(Bucket=bucket_name, Key=filename, Body=filetext)

    return {
        'statusCode': 200,
        'body': f'File {filename} written to {bucket_name}'
    }
